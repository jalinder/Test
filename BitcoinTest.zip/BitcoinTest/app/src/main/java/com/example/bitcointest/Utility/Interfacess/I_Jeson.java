package com.example.bitcointest.Utility.Interfacess;

import com.android.volley.VolleyError;

import org.json.JSONObject;

public interface I_Jeson {
    void notifySucces(int requestId, JSONObject response);

    void notifyErro(int requestId, VolleyError error);
}
