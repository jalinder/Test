package com.example.bitcointest;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.VolleyError;
import com.example.bitcointest.Utility.Common;
import com.example.bitcointest.Utility.Interfacess.IResult;
import com.example.bitcointest.Utility.Interfacess.I_Jeson;
import com.example.bitcointest.Utility.VolleyService;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private VolleyService mVolleyService;
    AlertDialog.Builder dialogBuilder;

    private IResult iResult;
    public static boolean check;
    ArrayList JsonfechObjList=new ArrayList();
    Spinner spinner;
    ArrayList codelist=new ArrayList();
    ArrayList symobl_price_List=new ArrayList();
    ArrayList price_List=new ArrayList();
    TextView txt_price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        JsonfechObjList.add("USD");
        JsonfechObjList.add("GBP");
        JsonfechObjList.add("EUR");
        txt_price=findViewById(R.id.txt_price);
        spinner=findViewById(R.id.spinner);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.getBackground().setColorFilter(getResources().getColor(R.color.colorWhite), PorterDuff.Mode.SRC_ATOP);


        getUserLogin();
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    TextView tv = (TextView) view;
                  ((TextView) parent.getChildAt(0)).setTextSize(18);
                  tv.setTextColor(getResources().getColor(R.color.colorWhite));
                  String Price= String.valueOf(price_List.get(position));

txt_price.setText(Price);
                  

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    private void getUserLogin() {

        // mBinding.progressBar.setVisibility(View.VISIBLE);
        initVolleyCallback();
        mVolleyService = new VolleyService(iResult, this);

        mVolleyService.postDataVolley(1, "https://api.coindesk.com/v1/bpi/currentprice.json");
    }

    private void initVolleyCallback() {

        iResult = new IResult() {


            @Override
            public void notifySuccess(int requestId, String response) {
                switch (requestId) {
                    case 1:
                        try {
                            JSONObject jsonObj = new JSONObject(String.valueOf(response));
                            //  int status = jsonObj.getInt("responseCode");
                            // String Massage = jsonObj.getString("message");
                            //  String otp=jsonObj.getString("otp");
                            //progressBar.setVisibility(View.GONE);
                            String code, symbol, rate, description, rate_float;
                            // Toast.makeText(getApplicationContext(),Massage,Toast.LENGTH_LONG).show();
                            // if (status==0) {

                            JSONObject categoryList = jsonObj.getJSONObject("bpi");

                            if (categoryList.length() != 0) {
                                for (int i = 0; i < categoryList.length(); i++) {


                                    JSONObject jsonObject1 = categoryList.getJSONObject(String.valueOf(JsonfechObjList.get(i)));
                                    code = jsonObject1.getString("code");
                                    symbol = jsonObject1.getString("symbol");
                                    rate = jsonObject1.getString("rate");
                                    description = jsonObject1.getString("description");
                                    rate_float = jsonObject1.getString("rate_float");
                                    symobl_price_List.add(symbol);
                                    price_List.add(rate_float);

                                    codelist.add(code);
                                }

                                ArrayAdapter adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_spinner_item, codelist);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                                spinner.setAdapter(adapter);

                                // }
                            }
                        } catch (JSONException e) {
                            // mainPgBarLayout.setVisibility(View.GONE);
                            // btnSignIn.setVisibility(View.VISIBLE);
                            e.printStackTrace();
                        }
                        break;
                }
            }

            @Override
            public void notifyError(int requestId, VolleyError error) {
                    Log.v("Volley RequestId", String.valueOf(requestId));
                    Log.v("Volly Error", String.valueOf(error));
            }




        };

    }
}
