package com.example.bitcointest.Utility;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpStack;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bitcointest.Utility.Interfacess.IResult;
import com.example.bitcointest.Utility.Interfacess.I_Jeson;

import org.json.JSONObject;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Admin on 06-12-2018.
 */

public class VolleyService {
    IResult mResultCallback = null;
    I_Jeson JSON_mResultCallback = null;
    Context mContext;
    RequestQueue queue;

    public VolleyService(IResult resultCallback, Context context) {
        mResultCallback = resultCallback;
        mContext = context;
    }

    public VolleyService(I_Jeson resultCallback, Context context) {
        JSON_mResultCallback = resultCallback;
        mContext = context;
    }


    public void postDataVolleyParameters(final int requestId, String url, final String params) {
        try {

            //ProviderInstaller.installIfNeeded(mContext);

            if (29 >= Build.VERSION_CODES.JELLY_BEAN
                    && 29 <= Build.VERSION_CODES.KITKAT) {

                HttpStack stack = null;
                try {
                    stack = new HurlStack(null, new TLSSocketFactory());
                } catch (KeyManagementException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                }


                queue = Volley.newRequestQueue(mContext, stack);
            } else {
                queue = Volley.newRequestQueue(mContext);
            }


            StringRequest stringRequest = new StringRequest(Request.Method.POST,
                    url, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    if (mResultCallback != null)
                        mResultCallback.notifySuccess(requestId, response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (mResultCallback != null)
                        mResultCallback.notifyError(requestId, error);
                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    //return params;
                    return null;
                }
            };


            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    5000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            queue.add(stringRequest);

        } catch (Exception e) {
            Log.v("VolleyServiceException", e.toString());
        }
    }


    public void postDataVolleyParametersJsonWithToken(final int requestId, String url, final Map<String, Object> params, final String Token) {
        try {

            //ProviderInstaller.installIfNeeded(mContext);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                    && Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {

                HttpStack stack = null;
                try {
                    stack = new HurlStack( null, new TLSSocketFactory());
                } catch (KeyManagementException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                }


                queue = Volley.newRequestQueue(mContext, stack);
            } else {
                queue = Volley.newRequestQueue(mContext);
            }
            JSONObject jsonObj = new JSONObject(params);


            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    url, new JSONObject(params),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            if (JSON_mResultCallback != null)
                                JSON_mResultCallback.notifySucces(requestId, response);

                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                  //   Toast.makeText(mContext.getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                                    if (JSON_mResultCallback != null)
                                        JSON_mResultCallback.notifyErro(requestId, error);
                                }
                            }) {
//                @Override
//                public String getBodyContentType() {
//                    return "application/json; charset=utf-8";
//                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                   // headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Content-Type", "application/json");
                    headers.put("Accept","application/json");
                    headers.put("Authorization","Bearer " + Token);
                    return headers;
                }
           };

            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(
                    50000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            queue.add(jsonObjReq);

        } catch (Exception e) {
            Log.v("VolleyServiceException", e.toString());
        }
    }

    public void postDataVolleyParametersJson(final int requestId, String url, final Map<String, String> params) {
        try {

            //ProviderInstaller.installIfNeeded(mContext);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                    && Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {

                HttpStack stack = null;
                try {
                    stack = new HurlStack(null, new TLSSocketFactory());
                } catch (KeyManagementException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                }


                queue = Volley.newRequestQueue(mContext, stack);
            } else {
                queue = Volley.newRequestQueue(mContext);
            }
            JSONObject jsonObj = new JSONObject(params);


            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    url, new JSONObject(params),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            if (JSON_mResultCallback != null)
                                JSON_mResultCallback.notifySucces(requestId, response);

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                       //     Toast.makeText(mContext.getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                            if (JSON_mResultCallback != null)
                                JSON_mResultCallback.notifyErro(requestId, error);
                        }
                    }) {
//                @Override
//                public String getBodyContentType() {
//                    return "application/json; charset=utf-8";
//                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }
            };

            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(
                    50000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            queue.add(jsonObjReq);

        } catch (Exception e) {
            Log.v("VolleyServiceException", e.toString());
        }
    }


    public void postDataVolleyParametersJsonArray(final int requestId, String url, final String params, final String Token) {
        try {

            //ProviderInstaller.installIfNeeded(mContext);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                    && Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {

                HttpStack stack = null;
                try {
                    stack = new HurlStack(null, new TLSSocketFactory());
                } catch (KeyManagementException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                }


                queue = Volley.newRequestQueue(mContext, stack);
            } else {
                queue = Volley.newRequestQueue(mContext);
            }
            JSONObject jsonObj = new JSONObject(params);


            JsonObjectRequest jsonObjRequest = new JsonObjectRequest

                    (Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            if (JSON_mResultCallback != null)
                                JSON_mResultCallback.notifySucces(requestId, response);

                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                                    if (JSON_mResultCallback != null)
                                        JSON_mResultCallback.notifyErro(requestId, error);
                                }


                            }){

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                // headers.put("Content-Type", "application/json; charset=utf-8");
                headers.put("Content-Type", "application/json");
                headers.put("Accept","application/json");
                headers.put("Authorization","Bearer " + Token);
                return headers;
            }
        };
            jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                    5000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            queue.add(jsonObjRequest);

        } catch (Exception e) {
            Log.v("VolleyServiceException", e.toString());
        }
    }

    public void postDataVolley(final int requestId, String url ) {
        try {
            final long mRequestStartTime  = System.currentTimeMillis(); // set the request start time just before you send the request.

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                    && Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {

                HttpStack stack = null;
                try {
                    stack = new HurlStack(null, new TLSSocketFactory());
                } catch (KeyManagementException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                }


                queue = Volley.newRequestQueue(mContext, stack);
            } else {
                queue = Volley.newRequestQueue(mContext);
            }


            StringRequest stringRequest = new StringRequest(Request.Method.GET,
                    url, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    if (mResultCallback != null)
                        mResultCallback.notifySuccess(requestId, response);

                    long totalRequestTime = System.currentTimeMillis() - mRequestStartTime;
                    Log.d("duration ",totalRequestTime+" :");

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (mResultCallback != null)
                        mResultCallback.notifyError(requestId, error);
                }
                });
//            }) {
//
//                @Override
//                public Map<String, String> getHeaders() throws AuthFailureError {
//                    HashMap<String, String> headers = new HashMap<String, String>();
//                    // headers.put("Content-Type", "application/json; charset=utf-8");
//                    headers.put("Content-Type", "application/json");
//                   // headers.put("Accept","application/json");
//                    headers.put("Authorization","Bearer " + Token);
//                    return headers;
//                }
          //  };

//            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
//                    5000,
//                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
//                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            queue.add(stringRequest);

        } catch (Exception e) {
            Log.v("VolleyServiceException", e.toString());
        }
    }


/*
    public void postDataVolleyJson(final int requestId, String url){
        try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                    && Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {

                HttpStack stack = null;
                try {
                    stack = new HurlStack(null, new TLSSocketFactory());
                } catch (KeyManagementException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                    Log.d("Your Wrapper Class", "Could not create new stack for TLS v1.2");
                    stack = new HurlStack();
                }


                queue = Volley.newRequestQueue(mContext,stack);
            }else{
                queue = Volley.newRequestQueue(mContext);
            }


            JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.GET,
                    url, new Response.Listener<JSONObject>() {

                @Override
                public void onResponse(JSONObject response) {
                    if(JSON_mResultCallback != null)
                        JSON_mResultCallback.notifySucces(requestId, response);
                }
                }

               , new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if(JSON_mResultCallback != null)
                        JSON_mResultCallback.notifyErro(requestId, error);
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {


                    return null;
                }
            };


            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    5000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            queue.add(stringRequest);

        }catch(Exception e){
            Log.v("VolleyServiceException", e.toString());
        }
    }
*/

    public void getDataVolley(final int requestId, String parm, String url) {
        try {
            RequestQueue queue = Volley.newRequestQueue(mContext);

            StringRequest stringRequest = new StringRequest(Request.Method.POST,
                    url, new Response.Listener<String>() {

                //  JsonObjectRequest jsonObj = new JsonObjectRequest(Request.Method.GET, url, new Response.Listener<JSONObject>() {

                @Override
                public void onResponse(String response) {
                    if (mResultCallback != null)
                        mResultCallback.notifySuccess(requestId, response);

                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (mResultCallback != null)
                        mResultCallback.notifyError(requestId, error);
                }
            });

            queue.add(stringRequest);

        } catch (Exception e) {

        }
    }
}
