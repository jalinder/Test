package com.example.bitcointest.Utility;

public  class Common {
    public static String BaseUrl=" https://qge9l9nkrd.execute-api.ap-south-1.amazonaws.com/Prod";
}
