package com.example.bitcointest.Utility;

/**
 * Created by Admin on 02-12-2017.
 */

public class ConstantVariables {

    public static final int USER_REGISTRATION = 1;


}
