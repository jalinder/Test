package com.example.bitcointest.Utility.Interfacess;


import com.android.volley.VolleyError;

public interface IResult {

    void notifySuccess(int requestId, String response);

    void notifyError(int requestId, VolleyError error);


}
